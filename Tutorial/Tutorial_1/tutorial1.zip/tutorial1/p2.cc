#include<iostream>
#include<string>
/*endl is for new line */
using namespace std;

int main(){
	int x, y;
	int product;
	cout << "Please enter two integers: "<<endl;
	cin >> x >> y;
	product = x * y;
	cout << "The product of " << x << " and " << y << " is " << product << "!"<<endl;





	return 0;



}
