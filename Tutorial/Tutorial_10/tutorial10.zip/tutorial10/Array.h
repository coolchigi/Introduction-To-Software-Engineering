
#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include "defs.h"

using namespace std;

template <class T>
class Array {

	public:
		//constructor
		Array();

		//destructor
		~Array();

		//other
		void add(T x);
		T operator[](int index);
		int getSize();
		bool isFull();

	private:
		int size;
		T elements[MAX_ARR];

};

template <class T> Array<T>::Array() : size(0){
	//elements = new int[MAX_ARR];

}

template <class T> Array<T>::~Array(){
	//delete [] elements;
}

template<class T>
void Array<T>::add(T t) { if (size < MAX_ARR) elements[size++] = t; }

template <class T>
int Array<T>::getSize(){
	return size;
}

template <class T>
bool Array<T>::isFull(){
	return size >= MAX_ARR;
}

template <class T>
T Array<T>::operator[](int index){
	if (index < 0 || index >= size) {
		cerr<<"Array index out of bounds"<<endl;
		exit(1);
	}
	return elements[index];
}

template<class T>
ostream& operator<<(ostream& output, const Array<T> arr) {
  output << arr.print();
  return output;
}

#endif
