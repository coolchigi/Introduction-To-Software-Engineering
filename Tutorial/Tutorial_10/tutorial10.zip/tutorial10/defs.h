#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR  256

#endif
