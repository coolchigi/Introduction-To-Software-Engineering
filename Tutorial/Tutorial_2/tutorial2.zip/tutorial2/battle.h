#ifndef BATTLE_H
#define BATTLE_H
#include "Character.h"

namespace Gondor{
  void fight(Character&, Character&);
}

namespace Mordor{
  void fight(Character&, Character&);
}


#endif
